# MY LIFE — Android project
Arabic RTL personal organizer. Data is stored locally on the device using WebView localStorage.

## Build APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: app/build/outputs/apk/debug/app-debug.apk

## Included
- Prayer times manually editable by city (no fabricated automatic timetable)
- Daily activities with completion toggle
- Study/exam schedule
- Tutoring lessons and cost per lesson
- Expense log and total in TND
- Workout log
- Sleep duration calculator
- Local device storage

Note: This source package is prepared for Android Studio. It is not a compiled APK.

## Build APK automatically in GitHub (no Android Studio needed locally)
1. Create a GitHub repository and upload the contents of this project.
2. Open the repository's Actions tab and run **Build MY LIFE APK** (or push to main).
3. When the workflow finishes, open its run and download the `MY-LIFE-debug-apk` artifact.
4. Extract the artifact and install `app-debug.apk` on your Android phone. Allow installation from your browser/file manager if Android asks.

The generated debug APK is for personal testing. It is not a Play Store release-signed build.
